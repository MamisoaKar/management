import { db } from "../config/db.js";

/**
 * Récupérer tous les départements
 */
export const getDepartments = async (req, res) => {
  try {
    const [rows] = await db.query("SELECT * FROM departments ORDER BY id DESC");
    res.json(rows);
  } catch (err) {
    console.error("Erreur getDepartments:", err.message);
    res.status(500).json({ error: "Erreur serveur" });
  }
};

/**
 * Alias : listDepartments = getDepartments
 */
export const listDepartments = getDepartments;

/**
 * Ajouter un département
 */
export const createDepartment = async (req, res) => {
  try {
    const { name, manager_id } = req.body;
    if (!name) return res.status(400).json({ message: "Nom requis." });

    const [result] = await db.query(
      "INSERT INTO departments (name, manager_id) VALUES (?, ?)",
      [name, manager_id || null]
    );

    res.status(201).json({
      message: "Département ajouté avec succès",
      departmentId: result.insertId,
    });
  } catch (err) {
    console.error("Erreur createDepartment:", err.message);
    res.status(500).json({ error: "Erreur serveur" });
  }
};

/**
 * Mettre à jour un département
 */
export const updateDepartment = async (req, res) => {
  try {
    const { id } = req.params;
    const { name, manager_id } = req.body;

    const [result] = await db.query(
      "UPDATE departments SET name = ?, manager_id = ? WHERE id = ?",
      [name, manager_id || null, id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Département introuvable." });
    }

    res.json({ message: "Département mis à jour avec succès" });
  } catch (err) {
    console.error("Erreur updateDepartment:", err.message);
    res.status(500).json({ error: "Erreur serveur" });
  }
};

/**
 * Supprimer un département
 */
export const deleteDepartment = async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await db.query(
      "DELETE FROM departments WHERE id = ?",
      [id]
    );

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: "Département introuvable." });
    }

    res.json({ message: "Département supprimé avec succès" });
  } catch (err) {
    console.error("Erreur deleteDepartment:", err.message);
    res.status(500).json({ error: "Erreur serveur" });
  }
};
