import bcrypt from 'bcryptjs'
import jwt from 'jsonwebtoken'
import { db } from '../config/db.js'

/* ---------- helpers ---------- */
function normId(v) {
  if (!v) return ''
  const s = String(v).trim()
  return s.includes('@') ? s.toLowerCase() : s
}

function signToken(user) {
  return jwt.sign(
    {
      id: user.id,
      email: user.email,
      employee_id: user.employee_id,
      full_name: user.full_name
    },
    process.env.JWT_SECRET,
    { expiresIn: '8h' }
  )
}

function looksHashed(p) {
  return typeof p === 'string' && /^\$2[aby]\$\d{2}\$[./A-Za-z0-9]{53}$/.test(p)
}

/* ---------- REGISTER ---------- */
export const register = async (req, res) => {
  try {
    const {
      employee_id = null,
      full_name = '',
      email = '',
      password = '',
      department = null,
      position = null,
      avatar_url = null
    } = req.body

    if (!full_name || !email || !password) {
      return res.status(400).json({ message: 'full_name, email et password sont requis.' })
    }
    const emailNorm = email.toLowerCase().trim()

    // unicité
    const [dupRows] = await db.query(
      'SELECT id FROM users WHERE email = ? OR employee_id = ? LIMIT 1',
      [emailNorm, employee_id || '']
    )
    if (dupRows.length) {
      return res.status(409).json({ message: 'Utilisateur déjà existant.' })
    }

    const hashed = looksHashed(password) ? password : await bcrypt.hash(password, 10)

    await db.query(
      `INSERT INTO users
        (employee_id, full_name, email, password, department, position, avatar_url, is_active)
       VALUES (?, ?, ?, ?, ?, ?, ?, 1)`,
      [employee_id, full_name, emailNorm, hashed, department, position, avatar_url]
    )

    return res.status(201).json({ message: 'Compte créé. Vous pouvez vous connecter.' })

  } catch (err) {
    console.error('register error:', err)
    return res.status(500).json({ message: 'Erreur serveur.' })
  }
}

/* ---------- LOGIN ---------- */
export const login = async (req, res) => {
  try {
    const { identifier, password } = req.body || {}
    if (!identifier || !password) {
      return res.status(400).json({ message: 'identifier et password sont requis.' })
    }

    const idNorm = normId(identifier)

    // Modification de la requête : on ne tente plus password_hash
    const [rows] = await db.query(
      'SELECT * FROM users WHERE email = ? OR employee_id = ? LIMIT 1',
      [idNorm, idNorm]
    )
    if (!rows.length) {
      return res.status(401).json({ message: 'Identifiants invalides.' })
    }

    const u = rows[0]
    const stored = u.password || ''  // on utilise seulement la colonne password

    let ok = false
    if (looksHashed(stored)) {
      ok = await bcrypt.compare(password, stored)
    } else {
      ok = String(password) === String(stored)
      if (ok) {
        const newHash = await bcrypt.hash(password, 10)
        await db.query('UPDATE users SET password = ? WHERE id = ?', [newHash, u.id])
      }
    }

    if (!ok) {
      return res.status(401).json({ message: 'Identifiants invalides.' })
    }

    const token = signToken(u)
    return res.json({
      token,
      user: {
        id: u.id,
        email: u.email,
        employee_id: u.employee_id,
        full_name: u.full_name,
        department: u.department,
        position: u.position,
        avatar_url: u.avatar_url
      }
    })
  } catch (err) {
    console.error('login error:', err)
    return res.status(500).json({ message: 'Erreur serveur.' })
  }
}

/* ---------- ME ---------- */
export const getProfile = async (req, res) => {
  try {
    const uid = req.user?.id
    if (!uid) {
      return res.status(401).json({ message: 'Non autorisé.' })
    }

    const [rows] = await db.query(
      `SELECT id, employee_id, full_name, email, department, position, avatar_url, is_active, created_at
       FROM users WHERE id = ? LIMIT 1`,
      [uid]
    )
    if (!rows.length) {
      return res.status(404).json({ message: 'Utilisateur introuvable.' })
    }

    return res.json(rows[0])
  } catch (err) {
    console.error('me error:', err)
    return res.status(500).json({ message: 'Erreur serveur.' })
  }
}
