import { db } from "../config/db.js";

/**
 * 🔹 Retrieve all available tasks
 */
export const getAvailableTasks = async (req, res) => {
  try {
    const [tasks] = await db.query(`
      SELECT id, title, status, priority, due_date
      FROM tasks
      ORDER BY id DESC
    `);
    res.json(tasks);
  } catch (error) {
    console.error("Error while loading tasks:", error);
    res.status(500).json({ message: "Server error while loading tasks." });
  }
};

/**
 * 🔹 Retrieve all available departments
 */
export const getDepartments = async (req, res) => {
  try {
    const [departments] = await db.query("SELECT id, name FROM departments ORDER BY id ASC");
    res.json(departments);
  } catch (error) {
    console.error("Error while loading departments:", error);
    res.status(500).json({ message: "Server error while loading departments." });
  }
};

/**
 * 🔹 Create one or more teams from a selected task
 */
export const createTeamsFromTask = async (req, res) => {
  const { task_id, team_count, department_ids } = req.body;

  if (!task_id || !team_count) {
    return res.status(400).json({ message: "task_id and team_count are required." });
  }

  try {
    const [taskRows] = await db.query("SELECT * FROM tasks WHERE id = ?", [task_id]);
    if (!taskRows.length) return res.status(404).json({ message: "Task not found." });

    const task = taskRows[0];
    const teamNameBase = task.title;
    const departments = Array.isArray(department_ids) ? department_ids : [];

    await db.query("START TRANSACTION");

    for (let i = 1; i <= team_count; i++) {
      const teamName = `${teamNameBase} - Team ${i}`;

      // Use INSERT IGNORE to avoid duplication
      const [result] = await db.query(
        "INSERT IGNORE INTO teams (name, task_id) VALUES (?, ?)",
        [teamName, task_id]
      );
      
      // Check if the insertion took place
      if (result.affectedRows > 0) {
        const teamId = result.insertId;

        // Add departments to the team if the insertion succeeded
        for (const deptId of departments) {
          await db.query(
            "INSERT INTO team_departments (team_id, department_id) VALUES (?, ?)",
            [teamId, deptId]
          );
        }
      }
    }

    await db.query("COMMIT");
    res.status(201).json({ message: `${team_count} team(s) created for '${task.title}'.` });
  } catch (error) {
    await db.query("ROLLBACK");
    console.error("Error creating teams:", error);
    res.status(500).json({ message: "Server error while creating teams." });
  }
};

/**
 * 🔹 Retrieve teams for a specific task, including departments
 */
export const getTeamsForTask = async (req, res) => {
  const { task_id } = req.params;
  
  try {
    // Retrieve teams associated with the task
    const [teams] = await db.query(`
      SELECT t.id, t.name, td.department_id, d.name AS department_name
      FROM teams t
      LEFT JOIN team_departments td ON t.id = td.team_id
      LEFT JOIN departments d ON td.department_id = d.id
      WHERE t.task_id = ?
      ORDER BY t.id ASC
    `, [task_id]);

    if (teams.length === 0) {
      return res.status(404).json({ message: "No teams found for this task." });
    }

    res.json(teams);  // Return the list of teams associated with the task
  } catch (error) {
    console.error("Error while loading teams:", error);
    res.status(500).json({ message: "Server error while loading teams." });
  }
};

/**
 * 🔹 Update a team
 */
export const updateTeam = async (req, res) => {
  const { team_id } = req.params;
  const { name, department_ids } = req.body;

  try {
    await db.query("START TRANSACTION");

    // Update the team's name
    await db.query("UPDATE teams SET name = ? WHERE id = ?", [name, team_id]);

    // Remove existing departments
    await db.query("DELETE FROM team_departments WHERE team_id = ?", [team_id]);

    // Add new departments
    for (const deptId of department_ids) {
      await db.query(
        "INSERT INTO team_departments (team_id, department_id) VALUES (?, ?)",
        [team_id, deptId]
      );
    }

    await db.query("COMMIT");
    res.status(200).json({ message: "Team updated successfully." });
  } catch (error) {
    await db.query("ROLLBACK");
    console.error("Error updating team:", error);
    res.status(500).json({ message: "Server error while updating the team." });
  }
};

/**
 * 🔹 Delete a team
 */
export const deleteTeam = async (req, res) => {
  const { team_id } = req.params;

  try {
    await db.query("START TRANSACTION");

    // Remove associated departments
    await db.query("DELETE FROM team_departments WHERE team_id = ?", [team_id]);

    // Delete the team
    await db.query("DELETE FROM teams WHERE id = ?", [team_id]);

    await db.query("COMMIT");
    res.status(200).json({ message: "Team deleted successfully." });
  } catch (error) {
    await db.query("ROLLBACK");
    console.error("Error deleting team:", error);
    res.status(500).json({ message: "Server error while deleting the team." });
  }
};
