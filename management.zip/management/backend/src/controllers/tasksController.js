// controllers/tasksController.js
import { db } from '../config/db.js'
 // ou le chemin correct vers ton module de connexion DB

const VALID_STATUS   = ['pending','in_progress','completed','cancelled'];
const VALID_PRIORITY = ['low','medium','high','urgent'];

export const getTasks = async (req, res) => {
  try {
    const [rows] = await db.query('SELECT * FROM tasks');
    return res.json(rows);
  } catch (e) {
    console.error('getTasks error', e);
    return res.status(500).json({ message: 'Erreur serveur' });
  }
};

export const createTask = async (req, res) => {
  try {
    const {
      title = '',
      description = null,
      assigned_to = null,
      assigned_by = null,
      status = 'pending',
      priority = 'medium',
      due_date = null
    } = req.body || {};

    if (!title.trim()) {
      return res.status(400).json({ message: 'title requis' });
    }

    const st = VALID_STATUS.includes(String(status)) ? String(status) : 'pending';
    const pr = VALID_PRIORITY.includes(String(priority)) ? String(priority) : 'medium';
    const due = due_date ? new Date(due_date) : null;
    const dueSql = due ? due.toISOString().slice(0,10) : null;

    const [r] = await db.query(
      `INSERT INTO tasks (title, description, assigned_to, assigned_by, status, priority, due_date)
       VALUES (?,?,?,?,?,?,?)`,
      [ title.trim(), description, assigned_to, assigned_by, st, pr, dueSql ]
    );

    const [rows] = await db.query('SELECT * FROM tasks WHERE id = ?', [r.insertId]);
    return res.status(201).json(rows[0]);
  } catch (e) {
    console.error('createTask error', e);
    return res.status(500).json({ message: 'Erreur serveur' });
  }
};

export const updateTask = async (req, res) => {
  try {
    const { id } = req.params;
    const {
      title,
      description,
      assigned_to,
      assigned_by,
      status,
      priority,
      due_date,
      completed_at
    } = req.body || {};

    const fields = [];
    const vals   = [];

    if (title !== undefined) {
      fields.push('title = ?');
      vals.push(String(title));
    }
    if (description !== undefined) {
      fields.push('description = ?');
      vals.push(description);
    }
    if (assigned_to !== undefined) {
      fields.push('assigned_to = ?');
      vals.push(assigned_to || null);
    }
    if (assigned_by !== undefined) {
      fields.push('assigned_by = ?');
      vals.push(assigned_by || null);
    }
    if (status !== undefined) {
      const st = VALID_STATUS.includes(String(status)) ? String(status) : 'pending';
      fields.push('status = ?');
      vals.push(st);
      if (st === 'completed' && completed_at === undefined) {
        fields.push('completed_at = NOW()');
      }
    }
    if (priority !== undefined) {
      const pr = VALID_PRIORITY.includes(String(priority)) ? String(priority) : 'medium';
      fields.push('priority = ?');
      vals.push(pr);
    }
    if (due_date !== undefined) {
      if (due_date) {
        const d = new Date(due_date);
        fields.push('due_date = ?');
        vals.push(d.toISOString().slice(0,10));
      } else {
        fields.push('due_date = NULL');
      }
    }
    if (completed_at !== undefined) {
      if (completed_at) {
        const d2 = new Date(completed_at);
        fields.push('completed_at = ?');
        vals.push(d2);
      } else {
        fields.push('completed_at = NULL');
      }
    }

    if (!fields.length) {
      return res.status(400).json({ message: 'Aucun champ à mettre à jour' });
    }

    vals.push(id);
    await db.query(`UPDATE tasks SET ${fields.join(', ')} WHERE id = ?`, vals);

    const [rows] = await db.query('SELECT * FROM tasks WHERE id = ?', [id]);
    return res.json(rows[0]);
  } catch (e) {
    console.error('updateTask error', e);
    return res.status(500).json({ message: 'Erreur serveur' });
  }
};

export const deleteTask = async (req, res) => {
  try {
    const { id } = req.params;

    const [result] = await db.query('DELETE FROM tasks WHERE id = ?', [id]);

    if (result.affectedRows === 0) {
      return res.status(404).json({ message: 'Tâche non trouvée' });
    }

    return res.json({ message: 'Tâche supprimée avec succès' });
  } catch (e) {
    console.error('deleteTask error', e);
    return res.status(500).json({ message: 'Erreur serveur' });
  }
};
