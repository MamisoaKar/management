import express from "express";
import {
  listDepartments,
  createDepartment,
  updateDepartment,
  deleteDepartment
} from "../controllers/departmentsController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// CRUD Departments (protégé)
router.get("/", protect, listDepartments);
router.post("/", protect, createDepartment);
router.put("/:id", protect, updateDepartment);
router.delete("/:id", protect, deleteDepartment);

export default router;