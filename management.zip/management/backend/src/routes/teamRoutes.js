import express from 'express';
import {
  getAvailableTasks,
  getDepartments,
  createTeamsFromTask
} from '../controllers/teamController.js';

const router = express.Router();

// 🔹 Récupérer les tâches
router.get('/tasks', getAvailableTasks);

// 🔹 Récupérer les départements
router.get('/departments', getDepartments);

// 🔹 Créer les équipes
router.post('/', createTeamsFromTask);

export default router;
