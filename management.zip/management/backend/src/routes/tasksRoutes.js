import express from "express";
import { getTasks, createTask, updateTask, deleteTask } from "../controllers/tasksController.js";
import { protect } from "../middleware/authMiddleware.js";

const router = express.Router();

// Toutes les routes tasks sont protégées
router.get("/", protect, getTasks);
router.post("/", protect, createTask);
router.put("/:id", protect, updateTask);
router.delete("/:id", protect, deleteTask);

export default router;