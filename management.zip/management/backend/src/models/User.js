export const User = {
    async findById(db, id) {
      const [rows] = await db.query(
        "SELECT * FROM users WHERE id = ? LIMIT 1",
        [id]
      );
      return rows[0] || null;
    },
  
    async findByEmailOrEmployee(db, identifier) {
      const [rows] = await db.query(
        "SELECT * FROM users WHERE email = ? OR employee_id = ? LIMIT 1",
        [identifier, identifier]
      );
      return rows[0] || null;
    },
  
    async create(db, user) {
      const [r] = await db.query(
        "INSERT INTO users (employee_id, full_name, email, password, department, position, avatar_url, is_active) VALUES (?, ?, ?, ?, ?, ?, ?, 1)",
        [
          user.employee_id,
          user.full_name,
          user.email,
          user.password,
          user.department,
          user.position,
          user.avatar_url,
        ]
      );
      return r.insertId;
    },
  
    async update(db, id, fields) {
      const allowed = [
        "full_name",
        "department",
        "position",
        "avatar_url",
        "is_active",
        "password",
      ];
  
      const sets = [];
      const vals = [];
  
      for (const key of allowed) {
        if (fields[key] !== undefined) {
          sets.push(`${key} = ?`);
          vals.push(fields[key]);
        }
      }
  
      if (sets.length === 0) return 0;
      vals.push(id);
  
      const [r] = await db.query(
        `UPDATE users SET ${sets.join(", ")} WHERE id = ?`,
        vals
      );
  
      return r.affectedRows;
    },
  
    async listAll(db) {
      const [rows] = await db.query(
        "SELECT id, full_name, email, department, position, avatar_url, is_active, created_at FROM users ORDER BY created_at DESC"
      );
      return rows;
    },
  };
  