export const Task = {
    async listAll(db) {
      const [rows] = await db.query(
        "SELECT * FROM tasks ORDER BY created_at DESC"
      );
      return rows;
    },
  
    async findById(db, id) {
      const [rows] = await db.query("SELECT * FROM tasks WHERE id = ?", [id]);
      return rows[0] || null;
    },
  
    async create(db, task) {
      const [r] = await db.query(
        "INSERT INTO tasks (title, description, priority, status, due_date, assigned_to, assigned_by) VALUES (?, ?, ?, ?, ?, ?, ?)",
        [
          task.title,
          task.description,
          task.priority,
          task.status,
          task.due_date,
          task.assigned_to,
          task.assigned_by,
        ]
      );
      return r.insertId;
    },
  
    async update(db, id, fields) {
      const allowed = [
        "title",
        "description",
        "priority",
        "status",
        "due_date",
        "assigned_to",
        "assigned_by",
        "completed_at",
      ];
  
      const sets = [];
      const vals = [];
  
      for (const key of allowed) {
        if (fields[key] !== undefined) {
          sets.push(`${key} = ?`);
          vals.push(fields[key]);
        }
      }
  
      if (sets.length === 0) return 0;
  
      vals.push(id);
  
      const [r] = await db.query(
        `UPDATE tasks SET ${sets.join(", ")} WHERE id = ?`,
        vals
      );
  
      return r.affectedRows;
    },
  
    async remove(db, id) {
      const [r] = await db.query("DELETE FROM tasks WHERE id = ?", [id]);
      return r.affectedRows;
    },
  };
  