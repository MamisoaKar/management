export const Department = {
    async listAll(db) {
      const [rows] = await db.query(
        "SELECT id, name, manager_id, created_at FROM departments ORDER BY name ASC"
      );
      return rows;
    },
  
    async findById(db, id) {
      const [rows] = await db.query(
        "SELECT id, name, manager_id, created_at FROM departments WHERE id = ? LIMIT 1",
        [id]
      );
      return rows[0] || null;
    },
  
    async create(db, department) {
      const [check] = await db.query(
        "SELECT id FROM departments WHERE name = ? LIMIT 1",
        [department.name]
      );
  
      if (check.length > 0) {
        throw new Error("Department already exists");
      }
  
      const [r] = await db.query(
        "INSERT INTO departments (name, manager_id) VALUES (?, ?)",
        [department.name, department.manager_id]
      );
      return r.insertId;
    },
  
    async update(db, id, fields) {
      const allowed = ["name", "manager_id"];
      const sets = [];
      const vals = [];
  
      for (const key of allowed) {
        if (fields[key] !== undefined) {
          sets.push(`${key} = ?`);
          vals.push(fields[key]);
        }
      }
  
      if (sets.length === 0) return 0;
      vals.push(id);
  
      const [r] = await db.query(
        `UPDATE departments SET ${sets.join(", ")} WHERE id = ?`,
        vals
      );
  
      return r.affectedRows;
    },
  
    async remove(db, id) {
      const [r] = await db.query("DELETE FROM departments WHERE id = ?", [id]);
      return r.affectedRows;
    },
  };
  