import { useState } from 'react'
import api from '../api/axios'

export default function AddTaskInline({ onAdded, compact }) {
  const [title, setTitle] = useState('')
  const [priority, setPriority] = useState('medium')
  const [dueDate, setDueDate] = useState('')
  const [status, setStatus] = useState('pending')
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState('')

  const submit = async (e) => {
    e.preventDefault()
    if (!title.trim()) return
    setSaving(true)
    setErr('')
    try {
      await api.post('/tasks', {
        title,
        priority,
        status,
        due_date: dueDate || null
      })
      setTitle(''); setPriority('medium'); setDueDate(''); setStatus('pending')
      onAdded && onAdded()
    } catch (e) {
      setErr('Failed to create task')
    } finally {
      setSaving(false)
    }
  }

  return (
    <form
      onSubmit={submit}
      className={'hw-card p-4 ' + (compact ? 'md:flex md:items-end md:gap-3' : '')}
    >
      <div className="mb-3 md:mb-0 md:flex-1">
        <label className="block text-xs hw-text-dim mb-1">Title</label>
        <input className="hw-input" value={title} onChange={e => setTitle(e.target.value)} placeholder="New task..." />
      </div>
      <div className="mb-3 md:mb-0">
        <label className="block text-xs hw-text-dim mb-1">Priority</label>
        <select className="hw-input" value={priority} onChange={e => setPriority(e.target.value)}>
          <option value="low">Low</option>
          <option value="medium">Medium</option>
          <option value="high">High</option>
          <option value="urgent">Urgent</option>
        </select>
      </div>
      <div className="mb-3 md:mb-0">
        <label className="block text-xs hw-text-dim mb-1">Status</label>
        <select className="hw-input" value={status} onChange={e => setStatus(e.target.value)}>
          <option value="pending">pending</option>
          <option value="in_progress">in_progress</option>
          <option value="completed">completed</option>
          <option value="cancelled">cancelled</option>
        </select>
      </div>
      <div className="mb-3 md:mb-0">
        <label className="block text-xs hw-text-dim mb-1">Due date</label>
        <input type="date" className="hw-input" value={dueDate} onChange={e => setDueDate(e.target.value)} />
      </div>
      <br />
      <button className="hw-btn" type="submit" disabled={saving}>
        {saving ? 'Saving…' : 'Add'}
      </button>
      {err && <div className="hw-text-dim text-sm ml-3">{err}</div>}
    </form>
  )
}