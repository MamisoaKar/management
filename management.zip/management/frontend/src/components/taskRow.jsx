import { useState } from 'react'
import api from '../api/axios'

export default function TaskRow({ task, onChanged }) {
  const [edit, setEdit] = useState(false)
  const [title, setTitle] = useState(task.title)
  const [priority, setPriority] = useState(task.priority || 'medium')
  const [status, setStatus] = useState(task.status || 'pending')
  const [due, setDue] = useState(task.due_date ? String(task.due_date).slice(0, 10) : '')
  const [saving, setSaving] = useState(false)
  const [err, setErr] = useState('')

  const save = async () => {
    setSaving(true); setErr('')
    try {
      await api.put('/tasks/' + task.id, {
        title,
        priority,
        status,
        due_date: due || null,
        completed_at: status === 'completed'
          ? new Date().toISOString().slice(0, 19).replace('T', ' ')
          : null
      })
      setEdit(false)
      onChanged && onChanged()
    } catch (e) {
      setErr('Save failed')
    } finally {
      setSaving(false)
    }
  }

  const del = async () => {
    if (!confirm('Delete this task?')) return
    await api.delete('/tasks/' + task.id)
    onChanged && onChanged()
  }

  return (
    <div className="hw-card p-3 flex items-center justify-between">
      {edit ? (
        <div className="flex-1 grid md:grid-cols-4 gap-2">
          <input className="hw-input" value={title} onChange={e => setTitle(e.target.value)} />
          <select className="hw-input" value={priority} onChange={e => setPriority(e.target.value)}>
            <option value="low">low</option>
            <option value="medium">medium</option>
            <option value="high">high</option>
            <option value="urgent">urgent</option>
          </select>
          <select className="hw-input" value={status} onChange={e => setStatus(e.target.value)}>
            <option value="pending">pending</option>
            <option value="in_progress">in_progress</option>
            <option value="completed">completed</option>
            <option value="cancelled">cancelled</option>
          </select>
          <input type="date" className="hw-input" value={due} onChange={e => setDue(e.target.value)} />
        </div>
      ) : (
        <div className="flex-1">
          <div className="font-medium">{task.title}</div>
          <div className="text-xs hw-text-dim">
            Priority: {task.priority || '—'} • Status: {task.status || '—'}
            {task.due_date ? ' • Due: ' + new Date(task.due_date).toLocaleDateString() : ''}
          </div>
        </div>
      )}

      <div className="flex items-center gap-2">
        {edit ? (
          <>
            <button onClick={save} className="hw-btn" disabled={saving}>{saving ? 'Saving…' : 'Save'}</button>
            <button onClick={() => setEdit(false)} className="hw-btn-ghost">Cancel</button>
          </>
        ) : (
          <>
            <button onClick={() => setEdit(true)} className="hw-btn-ghost">Edit</button>
            <button onClick={del} className="hw-btn-ghost" style={{ color: '#ff6b6b' }}>Delete</button>
          </>
        )}
      </div>
      {err && <div className="hw-text-dim text-sm ml-3">{err}</div>}
    </div>
  )
}