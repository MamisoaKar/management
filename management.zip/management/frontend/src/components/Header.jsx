import { useAuth } from '../context/AuthContext.jsx'

export default function Header({ title = 'Huawei Dashboard', onRefresh }) {
  const { user, logout } = useAuth()
  return (
    <header className="hw-card mb-4">
      <div className="hw-container" style={{ padding: '12px 16px', display: 'flex', alignItems: 'center', justifyContent: 'space-between', gap: 12 }}>
        <div className="font-semibold text-lg" style={{ color: '#d50000' }}>{title}</div>
        <div style={{ display: 'flex', alignItems: 'center', gap: 10 }}>
          {onRefresh && (
            <button type="button" className="hw-btn-ghost" onClick={onRefresh}>
              Refresh
            </button>
          )}
          <div className="hw-text-dim text-sm" style={{ whiteSpace: 'nowrap' }}>
            {user ? (user.full_name || user.email) : ''}
          </div>
          <button type="button" className="hw-btn" onClick={logout}>
            Logout
          </button>
        </div>
      </div>
    </header>
  )
}