import { NavLink } from 'react-router-dom'

function LinkItem({ to, label }) {
  return (
    <NavLink
      to={to}
      end
      className={({ isActive }) =>
        (isActive ? 'bg-[rgba(213,0,0,0.18)] ' : 'hover:bg-[rgba(255,255,255,0.06)] ') +
        'block px-4 py-2 rounded-lg text-sm'
      }
    >
      {label}
    </NavLink>
  )
}

export default function Sidebar() {
  return (
    <aside className="w-64 hw-card h-full p-3" style={{ position: 'sticky', top: 0 }}>
      <div className="px-2 py-3 font-extrabold text-lg" style={{ color: '#d50000' }}>Huawei</div>
      <nav className="space-y-1">
        <LinkItem to="/" label="Dashboard" />
        <LinkItem to="/tasks" label="Tasks" />
        <LinkItem to="/tasks/calendar" label="Status" />
        <LinkItem to="/team" label="Team" />
        <LinkItem to="/departments" label="Departments" />
        <LinkItem to="/profile" label="Profil" />
      </nav>
    </aside>
  )
}