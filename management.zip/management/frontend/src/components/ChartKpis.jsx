import {
  ResponsiveContainer,
  BarChart, Bar, XAxis, YAxis, Tooltip, CartesianGrid,
  LineChart, Line
} from 'recharts'

/**
 * tasks: [{ id, title, priority, status, created_at, due_date, ... }]
 * - Graph 1: Répartition par priorité (barres)
 * - Graph 2: Créations sur 10 derniers jours (ligne)
 */
export default function ChartKpis({ tasks }) {
  const priorities = ['low', 'medium', 'high', 'urgent']
  const byPriority = priorities.map(p => ({
    name: p[0].toUpperCase() + p.slice(1),
    count: tasks.filter(t => (t.priority || 'medium') === p).length
  }))

  // Série temporelle - 10 derniers jours (par created_at ou fallback à due_date)
  const days = [...Array(10)].map((_, i) => {
    const d = new Date()
    d.setDate(d.getDate() - (9 - i))
    const key = d.toISOString().slice(0, 10)
    return { key, label: d.toLocaleDateString(), count: 0 }
  })
  tasks.forEach(t => {
    const dt = (t.created_at || t.due_date || '').slice(0, 10)
    const bucket = days.find(d => d.key === dt)
    if (bucket) bucket.count += 1
  })
  const timeSeries = days.map(d => ({ date: d.label, tasks: d.count }))

  return (
    <div className="grid lg:grid-cols-2 gap-4">
  {/* Priorities Bar */}
  <div className="hw-card p-4">
    <div className="hw-text-dim text-sm mb-2">Tasks by Priority</div>
    <div style={{ width: '100%', height: 260 }}>
      <ResponsiveContainer>
        <BarChart 
          data={byPriority} 
          margin={{ top: 10, right: 40, left: 0, bottom: 0 }}
          barSize={20} // Ajouté ici pour réduire la largeur des barres globalement
        >
          <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
          <XAxis dataKey="name" stroke="rgba(255,255,255,0.65)" />
          <YAxis stroke="rgba(255,255,255,0.65)" allowDecimals={false} />
          <Tooltip
            contentStyle={{ background: '#0f1422', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12, color: '#fff' }}
            cursor={{ fill: 'rgba(255,255,255,0.06)' }}
          />
          <Bar 
            dataKey="count" 
            fill="#d50000" 
            radius={[8, 8, 8, 0]} 
            barSize={30} 
          />
        </BarChart>
      </ResponsiveContainer>
    </div>
  </div>


      {/* Time Series Line */}
      <div className="hw-card p-4">
        <div className="hw-text-dim text-sm mb-2">Tasks Created (Last 10 days)</div>
        <div style={{ width: '100%', height: 260 }}>
          <ResponsiveContainer>
            <LineChart data={timeSeries} margin={{ top: 10, right: 20, left: 0, bottom: 0 }}>
              <CartesianGrid stroke="rgba(255,255,255,0.08)" vertical={false} />
              <XAxis dataKey="date" stroke="rgba(255,255,255,0.65)" />
              <YAxis stroke="rgba(255,255,255,0.65)" allowDecimals={false} />
              <Tooltip
                contentStyle={{ background: '#0f1422', border: '1px solid rgba(255,255,255,0.12)', borderRadius: 12, color: '#fff' }}
                cursor={{ strokeDasharray: '3 3' }}
              />
              <Line type="monotone" dataKey="tasks" stroke="#2ad7ff" strokeWidth={2} dot={{ r: 3 }} activeDot={{ r: 5 }} />
            </LineChart>
          </ResponsiveContainer>
        </div>
      </div>
    </div>
  )
}