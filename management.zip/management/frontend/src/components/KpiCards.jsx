export default function KpiCards({ KPIs }) {
    const total = KPIs?.total || 0
    const completed = KPIs?.completed || 0
    const rate = KPIs?.completionRate || 0
    const overdue = KPIs?.overdue || 0
  
    return (
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <div className="hw-card p-4">
          <div className="hw-text-dim text-sm">Total tasks</div>
          <div className="text-2xl font-semibold mt-1">{total}</div>
        </div>
  
        <div className="hw-card p-4">
          <div className="hw-text-dim text-sm">Completed</div>
          <div className="text-2xl font-semibold mt-1">{completed}</div>
        </div>
  
        <div className="hw-card p-4">
          <div className="hw-text-dim text-sm">Completion rate</div>
          <div className="flex items-center justify-between mt-1 gap-3">
            <div className="text-lg font-semibold">{rate}%</div>
            <div
              className="hw-progress"
              style={{
                width: 160,
                height: 8,
                borderRadius: 9999,
                background: 'rgba(255,255,255,0.08)',
                border: '1px solid rgba(255,255,255,0.06)',
                overflow: 'hidden'
              }}
            >
              <span
                style={{
                  display: 'block',
                  height: '100%',
                  width: Math.max(0, Math.min(100, rate)) + '%',
                  background: 'linear-gradient(90deg, #2ad7ff, #7b2cff 60%, #d50000)'
                }}
              />
            </div>
          </div>
        </div>
  
        <div className="hw-card p-4">
          <div className="hw-text-dim text-sm">Overdue</div>
          <div className="text-2xl font-semibold mt-1">{overdue}</div>
        </div>
      </div>
    )
  }