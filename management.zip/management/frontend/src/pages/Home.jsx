import { useEffect, useMemo, useState } from 'react'
import api from '../api/axios'
import KpiCards from '../components/KpiCards'
import ChartKpis from '../components/ChartKpis'
import AddTaskInline from '../components/AddTaskInline'
import TaskRow from '../components/TaskRow'
export default function Home() {
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const fetchTasks = async () => {
    setLoading(true); setError('')
    try {
      const res = await api.get('/tasks')
      setTasks(Array.isArray(res.data) ? res.data : [])
    } catch {
      setError('Erreur de chargement des tâches')
    } finally {
      setLoading(false)
    }
  }
  useEffect(() => { fetchTasks() }, [])

  const KPIs = useMemo(() => {
    const total = tasks.length
    const completed = tasks.filter(t => t.status === 'completed').length
    const overdue = tasks.filter(t => t.due_date && new Date(t.due_date) < new Date() && t.status !== 'completed').length
    return { total, completed, completionRate: total ? Math.round((completed / total) * 100) : 0, overdue }
  }, [tasks])

  return (
    <div className="space-y-6">
      <KpiCards KPIs={KPIs} />
      <ChartKpis tasks={tasks} />
      <AddTaskInline onAdded={fetchTasks} compact />

      <div className="space-y-2">
        {loading && <div className="hw-text-dim">Chargement…</div>}
        {error && <div className="text-red-400">{error}</div>}
        {!loading && !tasks.length && <div className="hw-text-dim">Aucune tâche.</div>}
        {tasks.map(t => <TaskRow key={t.id} task={t} onChanged={fetchTasks} />)}
      </div>
    </div>
  )
}