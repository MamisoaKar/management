import { useEffect, useState } from 'react'
import api from '../api/axios'

export default function Departments() {
  const [list, setList] = useState([])
  const [name, setName] = useState('')
  const [loading, setLoading] = useState(false)
  const [editingId, setEditingId] = useState(null)
  const [editingName, setEditingName] = useState('')

  async function load() {
    setLoading(true)
    const res = await api.get('/departments')
    setList(res.data || [])
    setLoading(false)
  }

  useEffect(() => { load() }, [])

  async function add(e) {
    e.preventDefault()
    if (!name.trim()) return
    await api.post('/departments', { name: name.trim() })
    setName('')
    load()
  }

  async function remove(id) {
    if (!window.confirm('Supprimer ce département ?')) return
    await api.delete(`/departments/${id}`)
    load()
  }

  function startEditing(id, currentName) {
    setEditingId(id)
    setEditingName(currentName)
  }

  async function saveEdit(id) {
    if (!editingName.trim()) return alert('Le nom est requis')
    await api.put(`/departments/${id}`, { name: editingName.trim() })
    setEditingId(null)
    setEditingName('')
    load()
  }

  function cancelEdit() {
    setEditingId(null)
    setEditingName('')
  }

  return (
    <div>
      <form onSubmit={add} className="hw-card p-4 md:flex items-end gap-3 mb-4">
        <div className="md:flex-1">
          <label className="block text-xs hw-text-dim mb-1">New department</label>
          <input
            className="hw-input"
            value={name}
            onChange={e => setName(e.target.value)}
            placeholder="Ex: IT"
          />
        </div>
        <button className="hw-btn hw-btn-sm" type="submit">Add</button>
      </form>

      {loading && <div className="hw-text-dim">Loading</div>}

      <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-3">
        {list.map(d => (
          <div
            key={d.id}
            className="hw-card p-4 flex items-center justify-between relative group"
          >
            {editingId === d.id ? (
              <>
                <input
                  className="hw-input mr-2"
                  value={editingName}
                  onChange={e => setEditingName(e.target.value)}
                />
                <button
                  className="hw-btn hw-btn-sm mr-2"
                  onClick={() => saveEdit(d.id)}
                >
                  Enregistrer
                </button>
                <button
                  className="hw-btn hw-btn-secondary hw-btn-sm"
                  onClick={cancelEdit}
                >
                  Annuler
                </button>
              </>
            ) : (
              <>
                <div className="font-semibold">{d.name}</div>
                <div className="opacity-0 group-hover:opacity-100 transition-opacity flex gap-2">
                  <button
                    className="hw-btn hw-btn-sm"
                    onClick={() => startEditing(d.id, d.name)}
                  >
                    Update
                  </button>
                  <button
                    className="hw-btn hw-btn-danger hw-btn-sm"
                    onClick={() => remove(d.id)}
                  >
                    Delete
                  </button>
                </div>
              </>
            )}
          </div>
        ))}
      </div>

      {!loading && !list.length && <div className="hw-text-dim">No department yet.</div>}
    </div>
  )
}
