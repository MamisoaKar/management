import { useEffect, useState } from 'react'
import api from '../api/axios'

export default function TasksKanban() {
  const [tasks, setTasks] = useState([])
  const load = async () => {
    const res = await api.get('/tasks')
    setTasks(res.data || [])
  }
  useEffect(() => { load() }, [])

  const cols = ['pending', 'in_progress', 'completed', 'cancelled']

  return (
    <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
      {cols.map(s => (
        <div key={s} className="hw-card p-3">
          <div className="font-semibold mb-2 capitalize">{s.replace('_', ' ')}</div>
          {tasks.filter(t => t.status === s).map(t => (
            <div key={t.id} className="mb-2 p-2 rounded bg-[rgba(255,255,255,0.05)] text-sm">
              {t.title}
            </div>
          ))}
        </div>
      ))}
    </div>
  )
          }
