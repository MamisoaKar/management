import { useEffect, useState } from 'react'
import { useParams, Link } from 'react-router-dom'
import api from '../api/axios'

export default function DepartmentTeam() {
  const { id } = useParams()
  const [department, setDepartment] = useState(null)
  const [members, setMembers] = useState([])
  const [loading, setLoading] = useState(false)

  async function load() {
    setLoading(true)
    const dep = await api.get('/departments/' + id).catch(() => ({ data: null }))
    setDepartment(dep.data)
    const team = await api.get('/users/department/' + id).catch(() => ({ data: [] }))
    setMembers(team.data || [])
    setLoading(false)
  }
  useEffect(() => { load() }, [id])

  return (
    <div className="space-y-4">
      <Link className="hw-btn-ghost" to="/departments">← Retour aux départements</Link>

      <div className="hw-card p-3">
        <div className="font-semibold">Département</div>
        <div className="hw-text-dim text-sm">{department ? department.name : '—'}</div>
      </div>

      {loading && <div className="hw-text-dim">Chargement…</div>}

      <div className="grid md:grid-cols-3 gap-3">
        {members.map(u => (
          <div key={u.id} className="hw-card p-4">
            <div className="font-semibold">{u.full_name}</div>
            <div className="hw-text-dim text-sm">{u.position || 'Employé'}</div>
            <div className="text-xs mt-1">{u.department}</div>
            <div className="hw-text-dim text-xs mt-1">{u.email}</div>
          </div>
        ))}
      </div>

      {!loading && !members.length && <div className="hw-text-dim">Aucun membre trouvé.</div>}
    </div>
  )
}