import { useEffect, useMemo, useState } from 'react'
import api from '../api/axios'
import AddTaskInline from '../components/AddTaskInline'
import TaskRow from '../components/TaskRow'

const STATUS = ['pending', 'in_progress', 'completed', 'cancelled']
const PRIORITY = ['low', 'medium', 'high', 'urgent']

export default function TasksList() {
  const [tasks, setTasks] = useState([])
  const [loading, setLoading] = useState(false)
  const [q, setQ] = useState('')
  const [status, setStatus] = useState('')
  const [priority, setPriority] = useState('')

  async function load() {
    setLoading(true)
    try {
      const res = await api.get('/tasks')
      setTasks(Array.isArray(res.data) ? res.data : [])
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => { load() }, [])

  const filtered = useMemo(() => {
    return tasks
      .filter(t => (status ? t.status === status : true))
      .filter(t => (priority ? (t.priority || 'medium') === priority : true))
      .filter(t => (q ? (t.title || '').toLowerCase().includes(q.toLowerCase()) : true))
      .sort((a,b) => (b.id - a.id))
  }, [tasks, q, status, priority])

  return (
    <div className="space-y-4">
      {/* Ajout rapide */}
      <AddTaskInline onAdded={load} />

      {/* Barre filtres / recherche */}
      <div className="hw-card p-4 grid md:grid-cols-4 gap-3">
        <input
          className="hw-input md:col-span-2"
          placeholder="Find a Task"
          value={q}
          onChange={e => setQ(e.target.value)}
        />
        <select className="hw-input" value={status} onChange={e => setStatus(e.target.value)}>
          <option value=""> status</option>
          {STATUS.map(s => <option key={s} value={s}>{s}</option>)}
        </select>
        <select className="hw-input" value={priority} onChange={e => setPriority(e.target.value)}>
          <option value="">All priorities</option>
          {PRIORITY.map(p => <option key={p} value={p}>{p}</option>)}
        </select>
      </div>

      {/* Liste */}
      {loading && <div className="hw-text-dim">Loading...</div>}
      {!loading && !filtered.length && <div className="hw-text-dim">No task found.</div>}

      <div className="space-y-2">
        {filtered.map(t => (
          <TaskRow key={t.id} task={t} onChanged={load} />
        ))}
      </div>
    </div>
  )
}