import { useState } from 'react'
import { useNavigate } from 'react-router-dom' // Importer la fonction de navigation
import { useAuth } from '../context/AuthContext.jsx'

export default function Auth() {
  const { login, register, loading } = useAuth()  // Utilisation des actions du contexte
  const [tab, setTab] = useState('login')  // Détermine si on est en mode login ou register
  const [identifier, setIdentifier] = useState('')  // Email/ID pour login
  const [password, setPassword] = useState('')  // Mot de passe pour login
  const [form, setForm] = useState({ full_name: '', email: '', password: '', department: '', position: '' }) // Formulaire d'inscription
  const [error, setError] = useState('')  // Message d'erreur

  const navigate = useNavigate()  // Fonction pour naviguer après la connexion

  // Handler pour le login
  const handleLogin = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await login(identifier, password)  // Appel à la fonction login
      navigate('/dashboard')  // Redirection vers le dashboard après login réussi
    } catch {
      setError('Échec de connexion')
    }
  }

  // Handler pour l'inscription
  const handleRegister = async (e) => {
    e.preventDefault()
    setError('')
    try {
      await register(form)  // Appel à la fonction register
      setTab('login')  // Passer en mode login après inscription réussie
    } catch {
      setError('Échec de création du compte')
    }
  }

  return (
    <div className="login-screen">
      <div className="login-card">
        {/* Titre */}
        <h2 className="login-title">
          Sign in to continue your journey with <span>Huawei</span>.
        </h2>

        {/* Onglets + soulignement gradient */}
        <div className="login-tabs">
          <button
            type="button"
            className={'login-tab ' + (tab === 'login' ? 'active' : '')}
            onClick={() => setTab('login')}
          >
            Login
          </button>
          <button
            type="button"
            className={'login-tab ' + (tab === 'signup' ? 'active' : '')}
            onClick={() => setTab('signup')}
          >
            Sign up
          </button>
          <span className={'login-underline ' + (tab === 'signup' ? 'to-right' : '')} />
        </div>

        {error && <div className="login-error">{error}</div>}

        {tab === 'login' ? (
          <form onSubmit={handleLogin} className="space-y-4">
            <div>
              <label className="login-label">Email / Username</label>
              <input
                className="login-input"
                value={identifier}
                onChange={(e) => setIdentifier(e.target.value)}
                placeholder="m1234 or name@huawei.com"
              />
            </div>

            <div>
              <label className="login-label">Password</label>
              <input
                className="login-input"
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••••"
              />
              <div className="login-forgot">Forgot password?</div>
            </div>

            <button className="login-btn" disabled={loading}>
              {loading ? 'Connexion...' : 'Login'}
            </button>

            <div className="login-divider"><span>OR</span></div>

            <div className="login-foot">
              Don’t have an account?{' '}
              <button type="button" className="login-link" onClick={() => setTab('signup')}>
                Sign up
              </button>
            </div>
          </form>
        ) : (
          <form onSubmit={handleRegister} className="space-y-4">
            <div className="grid md:grid-cols-2 gap-3">
              <div>
                <label className="login-label">Full name</label>
                <input
                  className="login-input"
                  value={form.full_name}
                  onChange={(e) => setForm({ ...form, full_name: e.target.value })}
                />
              </div>
              <div>
                <label className="login-label">Employee ID (optional)</label>
                <input
                  className="login-input"
                  value={form.employee_id || ''}
                  onChange={(e) => setForm({ ...form, employee_id: e.target.value })}
                />
              </div>
            </div>

            <div>
              <label className="login-label">Corporate Email</label>
              <input
                className="login-input"
                value={form.email}
                onChange={(e) => setForm({ ...form, email: e.target.value })}
                placeholder="firstname.lastname@huawei.com"
              />
            </div>

            <div>
              <label className="login-label">Password</label>
              <input
                type="password"
                className="login-input"
                value={form.password}
                onChange={(e) => setForm({ ...form, password: e.target.value })}
              />
            </div>

            <button className="login-btn" disabled={loading}>
              {loading ? 'Création...' : 'Create my account'}
            </button>

            <div className="login-foot">
              Already have an account?{' '}
              <button type="button" className="login-link" onClick={() => setTab('login')}>
                Login
              </button>
            </div>
          </form>
        )}
      </div>
    </div>
  )
}
