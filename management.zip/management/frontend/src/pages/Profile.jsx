import { useEffect, useState } from 'react'
import api from '../api/axios'

export default function Profile() {
  const [profile, setProfile] = useState(null)
  const [saving, setSaving] = useState(false)
  const [msg, setMsg] = useState('')

  async function load() {
    const res = await api.get('/auth/me')
    setProfile(res.data)
  }
  useEffect(() => { load() }, [])

  const save = async (e) => {
    e.preventDefault()
    if (!profile?.id) return
    setSaving(true); setMsg('')
    try {
      const payload = {
        full_name: profile.full_name || '',
        department: profile.department || '',
        position: profile.position || '',
        avatar_url: profile.avatar_url || null
      }
      const res = await api.put('/users/' + profile.id, payload)
      setProfile(res.data)
      setMsg('Profil mis à jour ✅')
    } catch {
      setMsg('Échec de la mise à jour')
    } finally {
      setSaving(false)
    }
  }

  if (!profile) return <div className="hw-text-dim">Loading</div>

  return (
    <form onSubmit={save} className="hw-card p-4 max-w-xl space-y-3">
      <div className="text-sm hw-text-dim">Email (can't be updated)</div>
      <div className="hw-input opacity-70">{profile.email}</div>

      <div>
        <div className="text-sm hw-text-dim mb-1">Full Name</div>
        <input className="hw-input" value={profile.full_name || ''} onChange={e => setProfile({ ...profile, full_name: e.target.value })} />
      </div>

      <div>
        <div className="text-sm hw-text-dim mb-1">Department</div>
        <input className="hw-input" value={profile.department || ''} onChange={e => setProfile({ ...profile, department: e.target.value })} />
      </div>

      <div>
        <div className="text-sm hw-text-dim mb-1">Post</div>
        <input className="hw-input" value={profile.position || ''} onChange={e => setProfile({ ...profile, position: e.target.value })} />
      </div>

      <div>
        <div className="text-sm hw-text-dim mb-1">Avatar URL</div>
        <input className="hw-input" value={profile.avatar_url || ''} onChange={e => setProfile({ ...profile, avatar_url: e.target.value })} />
      </div>

      <button className="hw-btn" disabled={saving}>{saving ? 'Enregistrement…' : 'Enregistrer'}</button>
      {msg && <div className="hw-text-dim">{msg}</div>}
    </form>
  )
}