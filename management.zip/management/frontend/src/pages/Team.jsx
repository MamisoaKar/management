import { useEffect, useState } from 'react';
import api from '../api/axios';

export default function Team() {
  const [tasks, setTasks] = useState([]);          // Available tasks
  const [departments, setDepartments] = useState([]); // Available departments
  const [teams, setTeams] = useState([]);           // Created teams
  const [form, setForm] = useState({
    task_id: '',
    team_count: 1,
    department_ids: []
  });
  const [loading, setLoading] = useState(false);
  const [msg, setMsg] = useState('');

  // Load tasks and departments
  async function load() {
    setLoading(true);
    try {
      const [resTasks, resDeps] = await Promise.all([
        api.get('/team/tasks'),       // fetch the list of tasks
        api.get('/departments')       // fetch the list of departments
      ]);
      setTasks(resTasks.data || []);
      setDepartments(resDeps.data || []);
      setMsg('');
    } catch (err) {
      console.error('Error loading data:', err);
      setMsg('⚠️ Error loading data.');
    }
    setLoading(false);
  }

  useEffect(() => { load(); }, []);

  // Fetch teams for a specific task
  const fetchTeams = async (taskId) => {
    try {
      const res = await api.get(`/team/${taskId}/teams`);
      setTeams(res.data || []); // Update the created teams in state
    } catch (err) {
      console.error('Error loading teams:', err);
      setTeams([]); // If error, reset teams to an empty array
    }
  };

  // Handle form changes
  const handleChange = (e) => {
    const { name, value } = e.target;
    setForm(prev => ({ ...prev, [name]: value }));
  };

  // Handle multi-select changes
  const handleMultiSelect = (e) => {
    const ids = Array.from(e.target.selectedOptions).map(o => Number(o.value));
    setForm(prev => ({ ...prev, department_ids: ids }));
  };

  // Handle form submission
  const handleSubmit = async (e) => {
    e.preventDefault();
    setLoading(true);
    setMsg('');

    try {
      const res = await api.post('/team', form); // Call to createTeamsFromTask
      if (res.status === 201) {
        setMsg(res.data.message || '✅ Teams created successfully!');
        setForm({ task_id: '', team_count: 1, department_ids: [] });

        // Fetch and display created teams after submission
        fetchTeams(form.task_id); // Ensure form.task_id is defined
      } else {
        throw new Error('Error creating teams.');
      }
    } catch (err) {
      console.error('Error creating teams:', err);
      setMsg(err.response?.data?.message || 'Server error.');
    }
    setLoading(false);
  };

  // Update a team
  const handleUpdateTeam = async (teamId, newName, newDepartments) => {
    try {
      const res = await api.put(`/team/${teamId}`, {
        name: newName,
        department_ids: newDepartments
      });
      setMsg(res.data.message || 'Team updated successfully.');
      fetchTeams(form.task_id); // Refresh teams after modification
    } catch (err) {
      console.error('Error updating team:', err);
      setMsg('Error updating team.');
    }
  };

  // Delete a team
  const handleDeleteTeam = async (teamId) => {
    try {
      const res = await api.delete(`/team/${teamId}`);
      setMsg(res.data.message || 'Team deleted successfully.');
      fetchTeams(form.task_id); // Refresh teams after deletion
    } catch (err) {
      console.error('Error deleting team:', err);
      setMsg('Error deleting team.');
    }
  };

  return (
    <div className="space-y-6 p-4">
      <div className="hw-card p-4">
        <h2 className="text-lg font-semibold mb-3">➕ Create teams from a task</h2>
        <form onSubmit={handleSubmit} className="space-y-4">
          {/* Task selection */}
          <div>
            <label className="block text-sm mb-1">Select a task</label>
            <select
              name="task_id"
              value={form.task_id}
              onChange={handleChange}
              className="hw-input w-full"
              required
            >
              <option value="">-- Choose a task --</option>
              {tasks.map(t => (
                <option key={t.id} value={t.id}>
                  {t.title}
                </option>
              ))}
            </select>
          </div>

          {/* Number of teams to create */}
          {form.task_id && (
            <>
              <div>
                <label className="block text-sm mb-1">Number of teams to create</label>
                <input
                  type="number"
                  name="team_count"
                  value={form.team_count}
                  min="1"
                  max="10"
                  onChange={handleChange}
                  className="hw-input w-full"
                  required
                />
              </div>

              {/* Department selection */}
              <div>
                <label className="block text-sm mb-1">Associated departments</label>
                <select
                  multiple
                  value={form.department_ids}
                  onChange={handleMultiSelect}
                  className="hw-input w-full h-28"
                >
                  {departments.map(d => (
                    <option key={d.id} value={d.id}>
                      {d.name}
                    </option>
                  ))}
                </select>
              </div>
            </>
          )}

          {/* Submit button */}
          <button className="hw-btn-primary w-full" disabled={loading}>
            {loading ? 'Creating...' : 'Create teams'}
          </button>

          {msg && <div className="text-center mt-2 text-sm text-blue-500">{msg}</div>}
        </form>
      </div>

      {/* List of available tasks */}
      <div className="hw-card p-4">
        <h3 className="text-lg font-semibold mb-3">📋 Available tasks</h3>
        {tasks.length ? (
          <ul className="list-disc pl-6 space-y-1 text-sm">
            {tasks.map(t => (
              <li key={t.id}>
                <span className="font-medium">{t.title}</span> — <span>{t.status}</span>
              </li>
            ))}
          </ul>
        ) : (
          <div className="text-gray-400 text-sm">No tasks found.</div>
        )}
      </div>

      {/* List of created teams */}
      <div className="hw-card p-4">
        <h3 className="text-lg font-semibold mb-3">List of created teams</h3>
        {teams.length ? (
          <table className="min-w-full">
            <thead>
              <tr>
                <th>Team name</th>
                <th>Number of departments</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {teams.map(team => (
                <tr key={team.id}>
                  <td>{team.name}</td>
                  <td>{team.departments.length}</td>
                  <td>
                    <button onClick={() => handleUpdateTeam(team.id, 'New name', [])}>Edit</button>
                    <button onClick={() => handleDeleteTeam(team.id)}>Delete</button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        ) : (
          <div>No teams created for this task.</div>
        )}
      </div>
    </div>
  );
}
