import { createContext, useContext, useEffect, useState } from 'react'
import api from '../api/axios'
import { useNavigate } from 'react-router-dom'

const AuthCtx = createContext(null)

export function AuthProvider({ children }) {
  const [token, setToken] = useState(localStorage.getItem('token') || '')
  const [user, setUser] = useState(null)
  const [loading, setLoading] = useState(false)
  const navigate = useNavigate()

  async function fetchMe() {
    if (!token) return
    try {
      const res = await api.get('/auth/me')
      setUser(res.data)
    } catch (e) {
      logout()
    }
  }

  async function login(identifier, password) {
    setLoading(true)
    try {
      const res = await api.post('/auth/login', { identifier, password })
      const tok = res.data?.token
      if (!tok) throw new Error('No token')
      localStorage.setItem('token', tok)
      setToken(tok)
      await fetchMe()
      navigate('/', { replace: true })
    } finally {
      setLoading(false)
    }
  }

  async function register(form) {
    setLoading(true)
    try {
      const res = await api.post('/auth/register', form)
      // si l’API renvoie un token direct après register, dé-commente :
      // const tok = res.data?.token
      // if (tok) { localStorage.setItem('token', tok); setToken(tok); await fetchMe(); navigate('/', { replace: true }) }
      return res.data
    } finally {
      setLoading(false)
    }
  }

  function logout() {
    localStorage.removeItem('token')
    setToken('')
    setUser(null)
    navigate('/auth', { replace: true })
  }

  useEffect(() => { fetchMe() }, [token])

  return (
    <AuthCtx.Provider value={{ token, user, loading, login, register, logout }}>
      {children}
    </AuthCtx.Provider>
  )
}

export function useAuth() {
  return useContext(AuthCtx)
}