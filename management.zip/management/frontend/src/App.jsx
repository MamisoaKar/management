import { Routes, Route, Navigate, Outlet } from 'react-router-dom'
import { useAuth } from './context/AuthContext.jsx'

import Sidebar from './components/Sidebar.jsx'
import Header from './components/Header.jsx'

import Auth from './pages/Auth.jsx'
import Home from './pages/Home.jsx'
import TasksList from './pages/TasksList.jsx'
import TasksKanban from './pages/TasksKanban.jsx'
import TasksCalendar from './pages/TasksCalendar.jsx'
import Team from './pages/Team.jsx'
import Departments from './pages/Departments.jsx'
import DepartmentTeam from './pages/DepartmentTeam.jsx'
import Profile from './pages/Profile.jsx'

function PrivateRoute({ children }) {
  const { token } = useAuth()
  return token ? children : <Navigate to="/auth" replace />
}

/* === Layout global : sidebar fixe à gauche + header sticky en haut === */
function ProtectedLayout({ title }) {
  return (
    <div className="hw-bg h-screen w-screen overflow-hidden flex">
      {/* Sidebar occupe la hauteur complète, ne bouge pas */}
      <Sidebar />

      {/* Colonne principale : header sticky + zone qui scrolle */}
      <div className="flex-1 h-full flex flex-col min-w-0">
        <Header title={title} sticky />
        {/* c’est uniquement CETTE zone qui scrolle */}
        <main className="flex-1 overflow-y-auto p-6 space-y-6">
          <Outlet />
        </main>
      </div>
    </div>
  )
}

export default function App() {
  return (
    <Routes>
      {/* Auth sans layout */}
      <Route path="/auth" element={<Auth />} />

      {/* Dashboard */}
      <Route element={<PrivateRoute><ProtectedLayout title="Dashboard" /></PrivateRoute>}>
        <Route index element={<Home />} />
      </Route>

      {/* Tasks */}
      <Route element={<PrivateRoute><ProtectedLayout title="Tasks List" /></PrivateRoute>}>
        <Route path="/tasks" element={<TasksList />} />
      </Route>
      <Route element={<PrivateRoute><ProtectedLayout title="Kanban" /></PrivateRoute>}>
        <Route path="/tasks/kanban" element={<TasksKanban />} />
      </Route>
      <Route element={<PrivateRoute><ProtectedLayout title="Status" /></PrivateRoute>}>
        <Route path="/tasks/calendar" element={<TasksCalendar />} />
      </Route>

      {/* Team */}
      <Route element={<PrivateRoute><ProtectedLayout title="Team" /></PrivateRoute>}>
        <Route path="/team" element={<Team />} />
      </Route>

      {/* Departments */}
      <Route element={<PrivateRoute><ProtectedLayout title="Departments" /></PrivateRoute>}>
        <Route path="/departments" element={<Departments />} />
      </Route>
      <Route element={<PrivateRoute><ProtectedLayout title="Department Team" /></PrivateRoute>}>
        <Route path="/departments/:id/team" element={<DepartmentTeam />} />
      </Route>

      {/* Profile */}
      <Route element={<PrivateRoute><ProtectedLayout title="Profil" /></PrivateRoute>}>
        <Route path="/profile" element={<Profile />} />
      </Route>

      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  )
}